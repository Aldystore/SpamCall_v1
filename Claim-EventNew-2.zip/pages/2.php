                <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/1.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/2.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/3.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/4.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/5.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/6.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/cobra/7.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>