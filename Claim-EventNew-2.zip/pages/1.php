                <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/1.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/2.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/3.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/4.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/5.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/6.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/7.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/8.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/9.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/10.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/11.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/12.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/13.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/14.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/old/15.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>			    			                   