                <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/1.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/2.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/3.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/4.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/5.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/6.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/7.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/8.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/9.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/10.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/11.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>
			    
			    <div class="box">
			       <div class="prize">
			           <img src="ngMedia/hadiah/evo/12.jpg">
			       </div>
			       <div class="button" onclick="ambil(this)">
			         <img src="ngMedia/button.png">
			         <span class="text">Claim</span>
			       </div>
			    </div>    
			    